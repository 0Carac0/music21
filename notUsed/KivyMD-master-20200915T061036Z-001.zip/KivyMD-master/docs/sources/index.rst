Welcome to KivyMD's documentation!
==================================

.. autoapimodule:: kivymd

Contents
--------

.. toctree::
   :hidden:

   Home <self>

.. toctree::
   :maxdepth: 1

   /getting-started
   /themes/index
   /components/index
   /behaviors/index
   /changelog/index
   /about

.. toctree::
   :maxdepth: 1
   :titlesonly:

   Unincluded API </unincluded/kivymd/index>

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
