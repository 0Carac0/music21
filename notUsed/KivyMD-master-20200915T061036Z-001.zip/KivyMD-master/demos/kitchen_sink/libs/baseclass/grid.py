from kivy.uix.screenmanager import Screen


class KitchenSinkGrid(Screen):
    pass
